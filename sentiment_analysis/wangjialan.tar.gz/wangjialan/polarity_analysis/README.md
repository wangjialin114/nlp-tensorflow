## Sentiment Analysis

This is a sentiment analysis model for the imdb data.

### Prerequists

- numpy
- tensorflow

### Run

```
python main.py

```

### Thanks

some data read utils are referenced from keras.

